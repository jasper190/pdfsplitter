package pdf.reduce;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.stream.Collectors;

import javax.validation.Path;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.multipart.MultipartFile;

@Component("PostValidator")
public class PostValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Post.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// check for empty or whitespace;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sourceFile", "fileError", "filename not valid");

		Post p = (Post) target;
		File source = new File(p.getSourceFile());
		File destination = new File(p.getDestination());

		/*try {
			source = new File(p.getSourceFile());
			destination = new File(p.getDestination());
			System.out.println("file :"+p.getSourceFile());
		} catch (Exception e) {
			errors.rejectValue("sourceFile", "invalid path", "Please check your file path");
		}*/

		// check for file name
		if (!source.canRead()) {
			errors.rejectValue("sourceFile", "filenameError", "please check your file path");
		}

		// validate max number of pages for pdf;
		try {
			PDDocument validatepages = PDDocument.load(new File(source.getAbsolutePath()));
			final int PDF_MAX_PAGE = validatepages.getNumberOfPages();

			// initiate logic to get sections object list
			BuildLogic log = new BuildLogic();
			ArrayList<Section> sectionlist = new ArrayList<Section>();
			sectionlist = (ArrayList<Section>) log.parseNumberString(p);

			long invalidPages = sectionlist.stream().filter(x -> x.getStart() > PDF_MAX_PAGE
					|| x.getEnd() > PDF_MAX_PAGE || x.getStart() <= 0 || x.getEnd() <= 0)
					.collect(Collectors.counting());

			if (invalidPages > 0) {
				errors.rejectValue("split", "exceedNumRange", "Pages must be between 1 and " + PDF_MAX_PAGE);
			}

			validatepages.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (!destination.canWrite()) {
			errors.rejectValue("destination", "destinationErr", "Please check your saving directory");
		}

		// check if file is a valid pdf
		if (!source.getName().trim().toLowerCase().contains(".pdf")) {
			errors.rejectValue("sourceFile", "pdfError", "This does not seem like a valid pdf");
		}

	}

}
