package pdf.reduce;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component("Post")
public class Post {

	@NotNull
	private String sourceFile;
	@NotNull
	private String split;
	@NotNull
	private String destination;

	private String mergeOption = "merge";

	public String getSourceFile() {

		return sourceFile;
	}

	public String getSplit() {
		return split;
	}

	public void setSourceFile(String sourcefile) throws IOException {

		this.sourceFile = sourcefile;
	}

	public void setSplit(String split) {
		this.split = split;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getMergeOption() {
		return mergeOption;
	}

	public void setMergeOption(String mergeOption) {
		this.mergeOption = mergeOption;
	}

}
