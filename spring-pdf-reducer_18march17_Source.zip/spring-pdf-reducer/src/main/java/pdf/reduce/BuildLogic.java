package pdf.reduce;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

@Service
public class BuildLogic {

	public List<Section> parseNumberString(Post post) {
		List<Section> sectionList = new ArrayList<Section>();

		String requiredPages = post.getSplit();

		String[] pagesarray = requiredPages.split(",");
		List<String> pagelist = Arrays.asList(pagesarray);
		List<Section> sectionlist = new ArrayList<Section>();

		// splits an object from the list into two variable arrays if condition
		// is met.
		pagelist.stream().map(x -> x.split("-")).forEach(x -> {
			Section section = new Section();

			if (x.length > 1) {
				section.setStart(Integer.parseInt(x[0]));
				section.setEnd(Integer.parseInt(x[1]));
				System.out.println(x[0] + " " + x[1]);
				sectionlist.add(section);

			} else {
				section.setEnd(Integer.parseInt(x[0]));
				section.setStart(Integer.parseInt(x[0]));
				System.out.println(x[0]);
				sectionlist.add(section);
			}
		});// end anon function

		for (Section sec : sectionlist) {
			System.out.println(sec.getStart() + ":" + sec.getEnd());
		}

		return sectionlist;

	}// end function

	public ArrayList<String> pdfSlicing(ArrayList<Section> sectionlist, Post post, BindingResult bindingResult)  {
		
		
		//Remove invalid characters from the file path;
		
		String destination = post.getDestination().replace("\\", "/");
		
		File file = new File (post.getSourceFile().replace("\\", "/"));
		List<String> saveDocForMerge =new ArrayList<String>();
		
		final String pdfName = file.getName().toLowerCase().replace(".pdf", "_");
		
		try{
		int counter = 1;
		
		for(Section part :sectionlist){
			PDDocument document =PDDocument.load(file); //initialize the document each loop
			int start =part.getStart();
			int end=part.getEnd();
			
			
		Splitter splitter = new Splitter();
		
		
		if(start<end){
		 splitter.setStartPage(start);
		 splitter.setEndPage(end);
		 //splitter.setSplitAtPage(end-start+1);
		
		}//end start<end
		
		else if(start>end){
			splitter.setStartPage(end);
			splitter.setEndPage(start);
			//splitter.setSplitAtPage(start-end+1);
			
		}
		
		else if(start==end){
			splitter.setStartPage(start);
			splitter.setEndPage(end);
		}
		
		List<PDDocument> Pages = splitter.split(document);
		
		for (PDDocument page : Pages) {
			String currentdoc=destination+"/"+pdfName+"Pg" + counter + ".pdf";
			saveDocForMerge.add(currentdoc);
			page.save(currentdoc);
			counter++;
			page.close();
		}// end inner for loop
		
		document.close(); //close the document each loop
		
		}//end outer for loop
		
		}catch(Exception e){
			bindingResult.rejectValue("destination","savingErr", "Destination unable to save PDF");
		}//end try-catch
		

		return (ArrayList<String>) saveDocForMerge;
	}//end split function;
	
	public void mergePDF(ArrayList<String> DocsToMerge, Post post, BindingResult result){
		
		PDFMergerUtility merger = new PDFMergerUtility();
		merger.setDestinationFileName(post.getDestination()+"/Merged.pdf");
			
		HashSet<PDDocument> docstore = new HashSet<PDDocument>(); // exists to close the documents later on.
		
		DocsToMerge.stream().forEach(page->{
			File tempfile=new File(page);
			PDDocument tempdoc;
			try {
				tempdoc = PDDocument.load(tempfile);
			
			
			docstore.add(tempdoc);
			
				merger.addSource(tempfile);
				
			} catch (FileNotFoundException e) {
				result.reject("mergeFail", "Merging of document has failed");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
		});//end mergedoc stream.
		
		try {
			merger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			result.reject("mergeFail", "Saving document has failed");
		}
		
		docstore.stream().forEach(x->{
			
			try {
				x.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});//end closing stream;
		
	}// end merge function;
	

}//end Logic class;
