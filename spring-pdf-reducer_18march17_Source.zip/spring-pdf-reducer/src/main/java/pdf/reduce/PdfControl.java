package pdf.reduce;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MultipartFile;

@Controller
//@RequestMapping("/index.html")
public class PdfControl {
	@Autowired
	PostValidator validator;
	@Autowired
	BuildLogic log;
	

	@RequestMapping("/greeting")
	public String greeting(Model model) {
		model.addAttribute("post", new Post());
		System.out.println("first entry");
		return "greeting";
	}

	@PostMapping("/greeting")
	@ResponseStatus(HttpStatus.OK)
	public String onformpost(@Valid Post post, BindingResult bindingResult, MultipartFile file, Model model) {

		// BuildLogic log= new BuildLogic();
		List<Section> sectionlist = new ArrayList<Section>();
		System.out.println("second entry");

		ArrayList<String> saveDocForMerge = new ArrayList<String>();

		validator.validate(post, bindingResult); // adds a validator to the
													// model

		if (bindingResult.hasErrors()) {
			return "greeting";
		} // check for errors

		model.addAttribute("pdf_name", "hello.pdf");
		
		sectionlist = log.parseNumberString(post);

		saveDocForMerge = log.pdfSlicing((ArrayList<Section>) sectionlist, post, bindingResult);

		if (post.getMergeOption() != null && !saveDocForMerge.isEmpty()) {

			log.mergePDF(saveDocForMerge, post, bindingResult);

		} // if selection to merge is selected.

		return "greeting";
	}

	@RequestMapping("/")
	public String indexpage() {

		return "index";
	}

}// end class
